<?php
    header("Content-Type: text/html;charset=UTF-8");
    $conn = mysqli_connect("localhost","kyung0945","f9j9gz2q8bwg!","kyung0945");
    $data_stream = "'".$_POST['name']."','".$_POST['lat']."','".$_POST['lng']."'";
    $query = "insert into appdata (name,lat,lng) values (".$data_stream.")";
    $result = mysqli_query($conn, $query);
     
    if($result)
      echo "1";
    else
      echo "-1";
     
    mysqli_close($conn);
?>