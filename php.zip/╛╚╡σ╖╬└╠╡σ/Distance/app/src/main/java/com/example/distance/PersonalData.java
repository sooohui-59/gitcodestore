package com.example.distance;

public class PersonalData {
    private String member_name;
    private String member_lat;
    private String member_lng;
    private String member_distance;

    public String getMember_name() {
        return member_name;
    }

    public String getMember_lat() {
        return member_lat;
    }

    public String getMember_lng() {
        return member_lng;
    }

    public String getMember_distance() {
        return member_distance;
    }

    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public void setMember_lat(String member_lat) {
        this.member_lat = member_lat;
    }

    public void setMember_lng(String member_lng) {
        this.member_lng = member_lng;
    }

    public void setMember_distance(String member_distance) {
        this.member_distance = member_distance;
    }
}