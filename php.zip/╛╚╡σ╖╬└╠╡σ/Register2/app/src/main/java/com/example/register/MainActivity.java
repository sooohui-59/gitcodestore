package com.example.register;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.net.MalformedURLException;

public class MainActivity extends AppCompatActivity {
    private EditText name, lat, lng;
    private Button btn_send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NetworkUtil.setNetworkPolicy();
        name = findViewById(R.id.editText);
        lat = findViewById(R.id.editText2);
        lng = findViewById(R.id.editText3);
        btn_send = findViewById(R.id.btn_send);
        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    PHPRequest request = new PHPRequest("http://kyung0945.dothome.co.kr/datainsert.php");
                    String result = request.PhPtest(String.valueOf(name.getText()),String.valueOf(lat.getText()),String.valueOf(lng.getText()));
                    if(result.equals("1")){
                        Toast.makeText(getApplication(),"등록완료",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplication(),"등록실패",Toast.LENGTH_SHORT).show();
                    }
                }catch (MalformedURLException e){
                    e.printStackTrace();
                }
            }
        });
    }
}
