# **Naver Map SDK for Android**

네이버 클라우드 플랫폼 사용자를 위한 Android용 네이버 지도 라이브러리

Installation
==
- 상세한 내용은 [http://docs.ncloud.com/ko/naveropenapi_v3/maps/android-sdk/v2/start.html] 참고

## How to import

Android Studio

Add this to your build.gradle:

```
dependencies {
    implementation 'com.naver.maps.open:naver-map-ncp-api:2.1.7@aar'
}
```

Q&A
==
- https://www.ncloud.com/support/question/service


License
==

Copyright 2018 NAVER Corp.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
