/*
 * Copyright 2016 NAVER Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nhn.android.mapviewer;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionInflater;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.nhn.android.maps.NMapActivity;
import com.nhn.android.maps.NMapCompassManager;
import com.nhn.android.maps.NMapController;
import com.nhn.android.maps.NMapLocationManager;
import com.nhn.android.maps.NMapOverlay;
import com.nhn.android.maps.NMapOverlayItem;
import com.nhn.android.maps.NMapView;
import com.nhn.android.maps.maplib.NGeoPoint;
import com.nhn.android.maps.nmapmodel.NMapError;
import com.nhn.android.maps.nmapmodel.NMapPlacemark;
import com.nhn.android.maps.overlay.NMapCircleData;
import com.nhn.android.maps.overlay.NMapCircleStyle;
import com.nhn.android.maps.overlay.NMapPOIdata;
import com.nhn.android.maps.overlay.NMapPOIitem;
import com.nhn.android.maps.overlay.NMapPathData;
import com.nhn.android.maps.overlay.NMapPathLineStyle;
import com.nhn.android.mapviewer.overlay.NMapCalloutCustomOverlay;
import com.nhn.android.mapviewer.overlay.NMapCalloutOverlay;
import com.nhn.android.mapviewer.overlay.NMapMyLocationOverlay;
import com.nhn.android.mapviewer.overlay.NMapOverlayManager;
import com.nhn.android.mapviewer.overlay.NMapPOIdataOverlay;
import com.nhn.android.mapviewer.overlay.NMapPathDataOverlay;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class NMapViewer extends NMapActivity {
	private static final String LOG_TAG = "NMapViewer";
	private static final boolean DEBUG = false;
	private static final String CLIENT_ID = "fq9g8o30q1";

	private MapContainerView mMapContainerView;
	private NMapView mMapView;
	private NMapController mMapController;

	private static final NGeoPoint NMAP_LOCATION_DEFAULT = new NGeoPoint(126.978371, 37.5666091);
	private static final int NMAP_ZOOMLEVEL_DEFAULT = 11;
	private static final int NMAP_VIEW_MODE_DEFAULT = NMapView.VIEW_MODE_VECTOR;
	private static final boolean NMAP_TRAFFIC_MODE_DEFAULT = false;
	private static final boolean NMAP_BICYCLE_MODE_DEFAULT = false;

	private static final String KEY_ZOOM_LEVEL = "NMapViewer.zoomLevel";
	private static final String KEY_CENTER_LONGITUDE = "NMapViewer.centerLongitudeE6";
	private static final String KEY_CENTER_LATITUDE = "NMapViewer.centerLatitudeE6";
	private static final String KEY_VIEW_MODE = "NMapViewer.viewMode";
	private static final String KEY_TRAFFIC_MODE = "NMapViewer.trafficMode";
	private static final String KEY_BICYCLE_MODE = "NMapViewer.bicycleMode";

	private SharedPreferences mPreferences;

	private NMapOverlayManager mOverlayManager;

	private NMapMyLocationOverlay mMyLocationOverlay;
	private NMapLocationManager mMapLocationManager;
	private NMapCompassManager mMapCompassManager;

	private NMapViewerResourceProvider mMapViewerResourceProvider;

	private NMapPOIdataOverlay mFloatingPOIdataOverlay;
	private NMapPOIitem mFloatingPOIitem;

	private static boolean USE_XML_LAYOUT = false;

	private static String IP_ADDRESS = "kyung0945.dothome.co.kr";
	private static String TAG = "phptest";

	private ArrayList<PersonalData> mArrayList;
	private String mJsonString;

	/** Called when the activity is first created. */

	ViewGroup rootContainer;
	Transition trasitionMgr;
	Scene logo1;
	Scene selectdo;
	Scene centerview;
	Scene showpast;

	TextView _00_12;
	TextView _12_14;
	TextView _14_16;
	TextView _16_18;
	TextView _18_20;
	TextView _20_22;
	TextView _22_00;

	@RequiresApi(api = Build.VERSION_CODES.KITKAT)
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.logo1);

		rootContainer = (ViewGroup) findViewById(R.id.rootContainer);
		trasitionMgr = TransitionInflater.from(this).inflateTransition(R.transition.transition);

		logo1 = Scene.getSceneForLayout(rootContainer,R.layout.logo1,this);
		centerview = Scene.getSceneForLayout(rootContainer,R.layout.centerview,this);
		selectdo = Scene.getSceneForLayout(rootContainer,R.layout.selectdo,this);
		showpast = Scene.getSceneForLayout(rootContainer,R.layout.showpast,this);
		logo1.enter();

		if (USE_XML_LAYOUT) {
			setContentView(R.layout.logo1);
			mMapView = (NMapView)findViewById(R.id.mapView);
		} else {
			mMapView = new NMapView(this);
			mMapContainerView = new MapContainerView(this);
			mMapContainerView.addView(mMapView);
		}
		mMapView.setNcpClientId(CLIENT_ID);
		mMapView.setClickable(true);
		mMapView.setEnabled(true);
		mMapView.setFocusable(true);
		mMapView.setFocusableInTouchMode(true);
		mMapView.requestFocus();
		mMapView.setOnMapStateChangeListener(onMapViewStateChangeListener);
		mMapView.setOnMapViewTouchEventListener(onMapViewTouchEventListener);
		mMapView.setOnMapViewDelegate(onMapViewTouchDelegate);

		mMapController = mMapView.getMapController();
		NMapView.LayoutParams lp = new NMapView.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, NMapView.LayoutParams.BOTTOM_RIGHT);
		mMapView.setBuiltInZoomControls(true, lp);
		mMapViewerResourceProvider = new NMapViewerResourceProvider(this);
		super.setMapDataProviderListener(onDataProviderListener);

		mOverlayManager = new NMapOverlayManager(this, mMapView, mMapViewerResourceProvider);
		mOverlayManager.setOnCalloutOverlayListener(onCalloutOverlayListener);
		mOverlayManager.setOnCalloutOverlayViewListener(onCalloutOverlayViewListener);

		mMapLocationManager = new NMapLocationManager(this);
		mMapLocationManager.setOnLocationChangeListener(onMyLocationChangeListener);

		mMapCompassManager = new NMapCompassManager(this);

		mMyLocationOverlay = mOverlayManager.createMyLocationOverlay(mMapLocationManager, mMapCompassManager);

		mArrayList = new ArrayList<>();

	}

	private class GetData extends AsyncTask<String, Void, String> {

		ProgressDialog progressDialog;
		String errorString = "error";

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			progressDialog = ProgressDialog.show(NMapViewer.this,
					"Please Wait", null, true, true);
		}
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			progressDialog.dismiss();
			Log.d(TAG, "response - " + result);

			if (result == null){

				_00_12.setText(errorString);
			}
			else {
				mJsonString = result;
				showResult();
			}
		}

		@Override
		protected String doInBackground(String... params) {

			String serverURL = params[0];
			String postParameters = params[1];

			try {

				URL url = new URL(serverURL);
				HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

				httpURLConnection.setReadTimeout(5000);
				httpURLConnection.setConnectTimeout(5000);
				httpURLConnection.setRequestMethod("POST");
				httpURLConnection.setDoInput(true);
				httpURLConnection.connect();


				OutputStream outputStream = httpURLConnection.getOutputStream();
				outputStream.write(postParameters.getBytes("UTF-8"));
				outputStream.flush();
				outputStream.close();

				int responseStatusCode = httpURLConnection.getResponseCode();
				Log.d(TAG, "response code - " + responseStatusCode);

				InputStream inputStream;
				if(responseStatusCode == HttpURLConnection.HTTP_OK) {
					inputStream = httpURLConnection.getInputStream();
				}
				else{
					inputStream = httpURLConnection.getErrorStream();
				}

				InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

				StringBuilder sb = new StringBuilder();
				String line;

				while((line = bufferedReader.readLine()) != null){
					sb.append(line);
				}
				bufferedReader.close();
				return sb.toString().trim();
			} catch (Exception e) {
				Log.d(TAG, "GetData : Error ", e);
				errorString = e.toString();
				return null;
			}
		}
	}

	private String membera = "전체 좌석 : 15 / 남은 좌석 7";
	private String memberb = "전체 좌석 : 12 / 남은 좌석 8";
	private String memberc = "전체 좌석 : 6 / 남은 좌석 4";
	private String memberd = "전체 좌석 : 24 / 남은 좌석 11";
	private String membere = "전체 좌석 : 19 / 남은 좌석 16";
	private String memberf = "전체 좌석 : 21 / 남은 좌석 20";
	private String memberg = "전체 좌석 : 15 / 남은 좌석 5";
	private String memberh = "전체 좌석 : 9 / 남은 좌석 3";
	private String memberi = "전체 좌석 : 19 / 남은 좌석 9";

	private void showResult(){

		String TAG_JSON="webnautes";
		String TAG_NAME = "name";
		String TAG_0012 = "00_12";
		String TAG_1214 = "12_14";
		String TAG_1416 = "14_16";
		String TAG_1618 = "16_18";
		String TAG_1820 = "18_20";
		String TAG_2022 = "20_22";
		String TAG_2224 = "22_24";
//		String TAG_NOW = "now";

		try {
			JSONObject jsonObject = new JSONObject(mJsonString);
			JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

			EditText alpha = (EditText)findViewById(R.id.edittext);
			String beta = alpha.getText().toString();

			for(int i=0;i<jsonArray.length();i++){

				JSONObject item = jsonArray.getJSONObject(i);

				String name = item.getString(TAG_NAME);
				String a = item.getString(TAG_0012);
				String b = item.getString(TAG_1214);
				String c = item.getString(TAG_1416);
				String d = item.getString(TAG_1618);
				String e = item.getString(TAG_1820);
				String f = item.getString(TAG_2022);
				String g = item.getString(TAG_2224);
//				String h = item.getString(TAG_NOW);

					PersonalData personalData = new PersonalData();

					personalData.setMember_name(name);
					personalData.setMember_a(a);
					personalData.setMember_b(b);
					personalData.setMember_c(c);
					personalData.setMember_d(d);
					personalData.setMember_e(e);
					personalData.setMember_f(f);
					personalData.setMember_g(g);
//					personalData.setMember_h(h);

				mArrayList.add(personalData);

			}
		} catch (JSONException e) {
			Log.d(TAG, "showResult : ", e);
		}
	}
	public void goToCenterView(View view)
	{
		setContentView(mMapContainerView);
	}
	public void goToSelectDo(View view) { TransitionManager.go(selectdo,trasitionMgr);}
	public void goToShowPast(View view) {
		TransitionManager.go(showpast,trasitionMgr);
		Button button_all = (Button) findViewById(R.id.search);
		button_all.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {

				mArrayList.clear();

				GetData task = new GetData();
				task.execute( "http://kyung0945.dothome.co.kr/appdatamon.php", "");
				setTextView();
			}
		});
	}

	public void setTextView(){

		_00_12 = findViewById(R.id.q00);
		_12_14 = findViewById(R.id.q12);
		_14_16 = findViewById(R.id.q14);
		_16_18 = findViewById(R.id.q16);
		_18_20 = findViewById(R.id.q18);
		_20_22 = findViewById(R.id.q20);
		_22_00 = findViewById(R.id.q22);

	}


	@Override
	protected void onStart() {

		super.onStart();
		if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
			if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION) &&
					ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
				return;
			} else {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
				return;
			}
		}
	}

	@Override
	protected void onResume() {
		startMyLocation();
		testPOIdataOverlay();
		super.onResume();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		saveInstanceState();
		super.onDestroy();
	}

	private void startMyLocation() {

		if (mMyLocationOverlay != null) {
			if (!mOverlayManager.hasOverlay(mMyLocationOverlay)) {
				mOverlayManager.addOverlay(mMyLocationOverlay);
			}

			if (mMapLocationManager.isMyLocationEnabled()) {

				if (!mMapView.isAutoRotateEnabled()) {
					mMyLocationOverlay.setCompassHeadingVisible(true);

					mMapCompassManager.enableCompass();

					mMapView.setAutoRotateEnabled(true, false);

					mMapContainerView.requestLayout();
				} else {
					stopMyLocation();
				}

				mMapView.postInvalidate();
			} else {
				boolean isMyLocationEnabled = mMapLocationManager.enableMyLocation(true);
				if (!isMyLocationEnabled) {
					Toast.makeText(NMapViewer.this, "Please enable a My Location source in system settings",
						Toast.LENGTH_LONG).show();

					Intent goToSettings = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
					startActivity(goToSettings);

					return;
				}
			}
		}
	}

	private void stopMyLocation() {
		if (mMyLocationOverlay != null) {
			mMapLocationManager.disableMyLocation();

			if (mMapView.isAutoRotateEnabled()) {
				mMyLocationOverlay.setCompassHeadingVisible(false);

				mMapCompassManager.disableCompass();

				mMapView.setAutoRotateEnabled(false, false);

				mMapContainerView.requestLayout();
			}
		}
	}

	private void testPathDataOverlay() {
		NMapPathData pathData = new NMapPathData(9);

		pathData.initPathData();
		pathData.addPathPoint(127.108099, 37.366034, NMapPathLineStyle.TYPE_SOLID);
		pathData.addPathPoint(127.108088, 37.366043, 0);
		pathData.addPathPoint(127.108079, 37.365619, 0);
		pathData.addPathPoint(127.107458, 37.365608, 0);
		pathData.addPathPoint(127.107232, 37.365608, 0);
		pathData.addPathPoint(127.106904, 37.365624, 0);
		pathData.addPathPoint(127.105933, 37.365621, NMapPathLineStyle.TYPE_DASH);
		pathData.addPathPoint(127.105929, 37.366378, 0);
		pathData.addPathPoint(127.106279, 37.366380, 0);
		pathData.endPathData();

		NMapPathDataOverlay pathDataOverlay = mOverlayManager.createPathDataOverlay(pathData);
		if (pathDataOverlay != null) {

			NMapPathData pathData2 = new NMapPathData(4);
			pathData2.initPathData();
			pathData2.addPathPoint(127.106, 37.367, NMapPathLineStyle.TYPE_SOLID);
			pathData2.addPathPoint(127.107, 37.367, 0);
			pathData2.addPathPoint(127.107, 37.368, 0);
			pathData2.addPathPoint(127.106, 37.368, 0);
			pathData2.endPathData();
			pathDataOverlay.addPathData(pathData2);

			NMapPathLineStyle pathLineStyle = new NMapPathLineStyle(mMapView.getContext());
			pathLineStyle.setPataDataType(NMapPathLineStyle.DATA_TYPE_POLYGON);
			pathLineStyle.setLineColor(0xA04DD2, 0xff);
			pathLineStyle.setFillColor(0xFFFFFF, 0x00);
			pathData2.setPathLineStyle(pathLineStyle);

			NMapCircleData circleData = new NMapCircleData(1);
			circleData.initCircleData();
			circleData.addCirclePoint(127.1075, 37.3675, 50.0F);
			circleData.endCircleData();
			pathDataOverlay.addCircleData(circleData);

			NMapCircleStyle circleStyle = new NMapCircleStyle(mMapView.getContext());
			circleStyle.setLineType(NMapPathLineStyle.TYPE_DASH);
			circleStyle.setFillColor(0x000000, 0x00);
			circleData.setCircleStyle(circleStyle);

			pathDataOverlay.showAllPathData(0);
		}
	}

	private void testPathPOIdataOverlay() {
		NMapPOIdata poiData = new NMapPOIdata(4, mMapViewerResourceProvider, true);
		poiData.beginPOIdata(4);
		poiData.addPOIitem(349652983, 149297368, "Pizza 124-456", NMapPOIflagType.FROM, null);
		poiData.addPOIitem(349652966, 149296906, null, NMapPOIflagType.NUMBER_BASE + 1, null);
		poiData.addPOIitem(349651062, 149296913, null, NMapPOIflagType.NUMBER_BASE + 999, null);
		poiData.addPOIitem(349651376, 149297750, "Pizza 000-999", NMapPOIflagType.TO, null);
		poiData.endPOIdata();

		NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);

		poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);

	}

	private void testPOIdataOverlay() {

		int markerId = NMapPOIflagType.PIN;

		NMapPOIdata poiData = new NMapPOIdata(2, mMapViewerResourceProvider);
		poiData.beginPOIdata(2);

		NMapPOIitem item = poiData.addPOIitem(128.052643, 35.166009, "엠코아파트", markerId, 0);
		item.setRightAccessory(true, NMapPOIflagType.CLICKABLE_ARROW);
		poiData.addPOIitem(128.105648, 35.158850, "닭제이 "+membera, markerId, 0);
		poiData.addPOIitem(128.105352, 35.151423, "통묵은지감자탕 "+memberb, markerId, 0);
		poiData.addPOIitem(128.104959, 35.151387, "김해뒷고기 "+memberc, markerId, 0);
		poiData.addPOIitem(128.105685, 35.152032, "퇘장군 "+memberd, markerId, 0);
		poiData.addPOIitem(128.105625, 35.151521, "고메밀면 "+membere, markerId, 0);
		poiData.addPOIitem(128.105894, 35.152221, "홍콩반점 "+memberf, markerId, 0);
		poiData.addPOIitem(128.108686, 35.155170, "안골집 "+memberg, markerId, 0);
		poiData.addPOIitem(128.107481, 35.155144, "바깥집 "+memberh, markerId, 0);
		poiData.addPOIitem(128.108490, 35.155733, "겐코 " + memberi, markerId, 0);
		poiData.addPOIitem(128.107324, 35.153359, "경상스캔들 "+membera, markerId, 0);
		poiData.addPOIitem(128.106748, 35.154604, "핑크빛 청춘들 "+memberb, markerId, 0);
		poiData.addPOIitem(128.107547, 35.153122, "꾸븐 "+memberc, markerId, 0);
		poiData.addPOIitem(128.107321, 35.152457, "플랜비 "+memberd, markerId, 0);
		poiData.addPOIitem(128.107562, 35.152783, "돼지랑 순대랑 "+membere, markerId, 0);
		poiData.addPOIitem(128.106681, 35.153257, "주민회관 "+memberf, markerId, 0);
		poiData.endPOIdata();

		NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);

		poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);

		poiDataOverlay.selectPOIitem(0, true);
	}

	private void testFloatingPOIdataOverlay() {
		int marker1 = NMapPOIflagType.PIN;

		NMapPOIdata poiData = new NMapPOIdata(1, mMapViewerResourceProvider);
		poiData.beginPOIdata(1);
		NMapPOIitem item = poiData.addPOIitem(null, "Touch & Drag to Move", marker1, 0);
		if (item != null) {
			item.setPoint(mMapController.getMapCenter());
			item.setFloatingMode(NMapPOIitem.FLOATING_TOUCH | NMapPOIitem.FLOATING_DRAG);
			item.setRightButton(true);
			mFloatingPOIitem = item;
		}
		poiData.endPOIdata();

		NMapPOIdataOverlay poiDataOverlay = mOverlayManager.createPOIdataOverlay(poiData, null);
		if (poiDataOverlay != null) {
			poiDataOverlay.setOnFloatingItemChangeListener(onPOIdataFloatingItemChangeListener);
			poiDataOverlay.setOnStateChangeListener(onPOIdataStateChangeListener);
			poiDataOverlay.selectPOIitem(0, false);

			mFloatingPOIdataOverlay = poiDataOverlay;
		}
	}
	private final OnDataProviderListener onDataProviderListener = new OnDataProviderListener() {

		@Override
		public void onReverseGeocoderResponse(NMapPlacemark placeMark, NMapError errInfo) {

			if (DEBUG) {
				Log.i(LOG_TAG, "onReverseGeocoderResponse: placeMark="
					+ ((placeMark != null) ? placeMark.toString() : null));
			}

			if (errInfo != null) {
				Log.e(LOG_TAG, "Failed to findPlacemarkAtLocation: error=" + errInfo.toString());

				Toast.makeText(NMapViewer.this, errInfo.toString(), Toast.LENGTH_LONG).show();
				return;
			}

			if (mFloatingPOIitem != null && mFloatingPOIdataOverlay != null) {
				mFloatingPOIdataOverlay.deselectFocusedPOIitem();

				if (placeMark != null) {
					mFloatingPOIitem.setTitle(placeMark.toString());
				}
				mFloatingPOIdataOverlay.selectPOIitemBy(mFloatingPOIitem.getId(), false);
			}
		}

	};
	private final NMapLocationManager.OnLocationChangeListener onMyLocationChangeListener = new NMapLocationManager.OnLocationChangeListener() {

		@Override
		public boolean onLocationChanged(NMapLocationManager locationManager, NGeoPoint myLocation) {

			if (mMapController != null) {
				mMapController.animateTo(myLocation);
			}

			return true;
		}

		@Override
		public void onLocationUpdateTimeout(NMapLocationManager locationManager) {
			Toast.makeText(NMapViewer.this, "Your current location is temporarily unavailable.", Toast.LENGTH_LONG).show();
		}

		@Override
		public void onLocationUnavailableArea(NMapLocationManager locationManager, NGeoPoint myLocation) {
			Toast.makeText(NMapViewer.this, "Your current location is unavailable area.", Toast.LENGTH_LONG).show();
			stopMyLocation();
		}

	};
	private final NMapView.OnMapStateChangeListener onMapViewStateChangeListener = new NMapView.OnMapStateChangeListener() {

		@Override
		public void onMapInitHandler(NMapView mapView, NMapError errorInfo) {

			if (errorInfo == null) { // success
				restoreInstanceState();

			} else {
				Log.e(LOG_TAG, "onFailedToInitializeWithError: " + errorInfo.toString());
				Toast.makeText(NMapViewer.this, errorInfo.toString(), Toast.LENGTH_LONG).show();
			}
		}

		@Override
		public void onAnimationStateChange(NMapView mapView, int animType, int animState) {
			if (DEBUG) {
				Log.i(LOG_TAG, "onAnimationStateChange: animType=" + animType + ", animState=" + animState);
			}
		}

		@Override
		public void onMapCenterChange(NMapView mapView, NGeoPoint center) {
			if (DEBUG) {
				Log.i(LOG_TAG, "onMapCenterChange: center=" + center.toString());
			}
		}

		@Override
		public void onZoomLevelChange(NMapView mapView, int level) {
			if (DEBUG) {
				Log.i(LOG_TAG, "onZoomLevelChange: level=" + level);
			}
		}

		@Override
		public void onMapCenterChangeFine(NMapView mapView) {

		}
	};

	private final NMapView.OnMapViewTouchEventListener onMapViewTouchEventListener = new NMapView.OnMapViewTouchEventListener() {

		@Override
		public void onLongPress(NMapView mapView, MotionEvent ev) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onLongPressCanceled(NMapView mapView) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSingleTapUp(NMapView mapView, MotionEvent ev) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onTouchDown(NMapView mapView, MotionEvent ev) {

		}

		@Override
		public void onScroll(NMapView mapView, MotionEvent e1, MotionEvent e2) {
		}

		@Override
		public void onTouchUp(NMapView mapView, MotionEvent ev) {
			// TODO Auto-generated method stub

		}

	};

	private final NMapView.OnMapViewDelegate onMapViewTouchDelegate = new NMapView.OnMapViewDelegate() {

		@Override
		public boolean isLocationTracking() {
			if (mMapLocationManager != null) {
				if (mMapLocationManager.isMyLocationEnabled()) {
					return mMapLocationManager.isMyLocationFixed();
				}
			}
			return false;
		}

	};
	private final NMapPOIdataOverlay.OnStateChangeListener onPOIdataStateChangeListener = new NMapPOIdataOverlay.OnStateChangeListener() {

		@Override
		public void onCalloutClick(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item) {
			if (DEBUG) {
				Log.i(LOG_TAG, "onCalloutClick: title=" + item.getTitle());
			}
			Toast.makeText(NMapViewer.this, "onCalloutClick: " + item.getTitle(), Toast.LENGTH_LONG).show();
		}

		@Override
		public void onFocusChanged(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item) {
			if (DEBUG) {
				if (item != null) {
					Log.i(LOG_TAG, "onFocusChanged: " + item.toString());
				} else {
					Log.i(LOG_TAG, "onFocusChanged: ");
				}
			}
		}
	};

	private final NMapPOIdataOverlay.OnFloatingItemChangeListener onPOIdataFloatingItemChangeListener = new NMapPOIdataOverlay.OnFloatingItemChangeListener() {

		@Override
		public void onPointChanged(NMapPOIdataOverlay poiDataOverlay, NMapPOIitem item) {
			NGeoPoint point = item.getPoint();

			if (DEBUG) {
				Log.i(LOG_TAG, "onPointChanged: point=" + point.toString());
			}

			findPlacemarkAtLocation(point.longitude, point.latitude);

			item.setTitle(null);

		}
	};

	private final NMapOverlayManager.OnCalloutOverlayListener onCalloutOverlayListener = new NMapOverlayManager.OnCalloutOverlayListener() {

		@Override
		public NMapCalloutOverlay onCreateCalloutOverlay(NMapOverlay itemOverlay, NMapOverlayItem overlayItem,
			Rect itemBounds) {
			if (itemOverlay instanceof NMapPOIdataOverlay) {
				NMapPOIdataOverlay poiDataOverlay = (NMapPOIdataOverlay)itemOverlay;

				if (!poiDataOverlay.isFocusedBySelectItem()) {
					int countOfOverlappedItems = 1;

					NMapPOIdata poiData = poiDataOverlay.getPOIdata();
					for (int i = 0; i < poiData.count(); i++) {
						NMapPOIitem poiItem = poiData.getPOIitem(i);

						if (poiItem == overlayItem) {
							continue;
						}

						if (Rect.intersects(poiItem.getBoundsInScreen(), overlayItem.getBoundsInScreen())) {
							countOfOverlappedItems++;
						}
					}

					if (countOfOverlappedItems > 1) {
						String text = countOfOverlappedItems + " overlapped items for " + overlayItem.getTitle();
						Toast.makeText(NMapViewer.this, text, Toast.LENGTH_LONG).show();
						return null;
					}
				}
			}
			if (overlayItem instanceof NMapPOIitem) {
				NMapPOIitem poiItem = (NMapPOIitem)overlayItem;

				if (poiItem.showRightButton()) {
					return new NMapCalloutCustomOldOverlay(itemOverlay, overlayItem, itemBounds,
						mMapViewerResourceProvider);
				}
			}
			return new NMapCalloutCustomOverlay(itemOverlay, overlayItem, itemBounds, mMapViewerResourceProvider);
		}

	};

	private final NMapOverlayManager.OnCalloutOverlayViewListener onCalloutOverlayViewListener = new NMapOverlayManager.OnCalloutOverlayViewListener() {

		@Override
		public View onCreateCalloutOverlayView(NMapOverlay itemOverlay, NMapOverlayItem overlayItem, Rect itemBounds) {

			if (overlayItem != null) {
				String title = overlayItem.getTitle();
				if (title != null && title.length() > 5) {
					return new NMapCalloutCustomOverlayView(NMapViewer.this, itemOverlay, overlayItem, itemBounds);
				}
			}
			return null;
		}

	};
	private static boolean mIsMapEnlared = false;

	private void restoreInstanceState() {
		mPreferences = getPreferences(MODE_PRIVATE);

		int longitudeE6 = mPreferences.getInt(KEY_CENTER_LONGITUDE, NMAP_LOCATION_DEFAULT.getLongitudeE6());
		int latitudeE6 = mPreferences.getInt(KEY_CENTER_LATITUDE, NMAP_LOCATION_DEFAULT.getLatitudeE6());
		int level = mPreferences.getInt(KEY_ZOOM_LEVEL, NMAP_ZOOMLEVEL_DEFAULT);
		int viewMode = mPreferences.getInt(KEY_VIEW_MODE, NMAP_VIEW_MODE_DEFAULT);
		boolean trafficMode = mPreferences.getBoolean(KEY_TRAFFIC_MODE, NMAP_TRAFFIC_MODE_DEFAULT);
		boolean bicycleMode = mPreferences.getBoolean(KEY_BICYCLE_MODE, NMAP_BICYCLE_MODE_DEFAULT);

		mMapController.setMapViewMode(viewMode);
		mMapController.setMapViewTrafficMode(trafficMode);
		mMapController.setMapViewBicycleMode(bicycleMode);
		mMapController.setMapCenter(new NGeoPoint(longitudeE6, latitudeE6), level);

		if (mIsMapEnlared) {
			mMapView.setScalingFactor(2.0F);
		} else {
			mMapView.setScalingFactor(1.0F);
		}
	}

	private void saveInstanceState() {
		if (mPreferences == null) {
			return;
		}

		NGeoPoint center = mMapController.getMapCenter();
		int level = mMapController.getZoomLevel();
		int viewMode = mMapController.getMapViewMode();
		boolean trafficMode = mMapController.getMapViewTrafficMode();
		boolean bicycleMode = mMapController.getMapViewBicycleMode();

		SharedPreferences.Editor edit = mPreferences.edit();

		edit.putInt(KEY_CENTER_LONGITUDE, center.getLongitudeE6());
		edit.putInt(KEY_CENTER_LATITUDE, center.getLatitudeE6());
		edit.putInt(KEY_ZOOM_LEVEL, level);
		edit.putInt(KEY_VIEW_MODE, viewMode);
		edit.putBoolean(KEY_TRAFFIC_MODE, trafficMode);
		edit.putBoolean(KEY_BICYCLE_MODE, bicycleMode);

		edit.commit();

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		int viewMode = mMapController.getMapViewMode();
		boolean isTraffic = mMapController.getMapViewTrafficMode();
		boolean isBicycle = mMapController.getMapViewBicycleMode();
        boolean isAlphaLayer = mMapController.getMapAlphaLayerMode();

		menu.findItem(R.id.action_revert).setEnabled((viewMode != NMapView.VIEW_MODE_VECTOR) || isTraffic || mOverlayManager.sizeofOverlays() > 0);
		menu.findItem(R.id.action_vector).setChecked(viewMode == NMapView.VIEW_MODE_VECTOR);
		menu.findItem(R.id.action_satellite).setChecked(viewMode == NMapView.VIEW_MODE_HYBRID);
		menu.findItem(R.id.action_traffic).setChecked(isTraffic);
		menu.findItem(R.id.action_bicycle).setChecked(isBicycle);
        menu.findItem(R.id.action_alpha_layer).setChecked(isAlphaLayer);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.action_revert:
				if (mMyLocationOverlay != null) {
					stopMyLocation();
					mOverlayManager.removeOverlay(mMyLocationOverlay);
				}

				mMapController.setMapViewMode(NMapView.VIEW_MODE_VECTOR);
				mMapController.setMapViewTrafficMode(false);
				mMapController.setMapViewBicycleMode(false);

				mOverlayManager.clearOverlays();
				return true;
			case R.id.action_vector:
				invalidateMenu();
				mMapController.setMapViewMode(NMapView.VIEW_MODE_VECTOR);
				return true;

			case R.id.action_satellite:
				invalidateMenu();
				mMapController.setMapViewMode(NMapView.VIEW_MODE_HYBRID);
				return true;

			case R.id.action_traffic:
				invalidateMenu();
				mMapController.setMapViewTrafficMode(!mMapController.getMapViewTrafficMode());
				return true;

			case R.id.action_bicycle:
				invalidateMenu();
				mMapController.setMapViewBicycleMode(!mMapController.getMapViewBicycleMode());
				return true;

			case R.id.action_zoom:
				mMapView.displayZoomControls(true);
				return true;

			case R.id.action_my_location:
				startMyLocation();
				return true;

			case R.id.action_poi_data:
				mOverlayManager.clearOverlays();

				testPOIdataOverlay();
				return true;

			case R.id.action_path_data:
				mOverlayManager.clearOverlays();

				testPathDataOverlay();
				testPathPOIdataOverlay();
				return true;

			case R.id.action_floating_data:
				mOverlayManager.clearOverlays();
				testFloatingPOIdataOverlay();
				return true;

			case R.id.action_new_activity:
				Intent intent = new Intent(this, FragmentMapActivity.class);
				startActivity(intent);
				return true;

			case R.id.action_visible_bounds:
				Rect viewFrame = mMapView.getMapController().getViewFrameVisible();
				mMapController.setBoundsVisible(0, 0, viewFrame.width(), viewFrame.height() - 200);
				mOverlayManager.clearOverlays();

				testPathDataOverlay();
				return true;

			case R.id.action_scale_factor:
				if (mMapView.getMapProjection().isProjectionScaled()) {
					if (mMapView.getMapProjection().isMapHD()) {
						mMapView.setScalingFactor(2.0F, false);
					} else {
						mMapView.setScalingFactor(1.0F, false);
					}
				} else {
					mMapView.setScalingFactor(2.0F, true);
				}
				mIsMapEnlared = mMapView.getMapProjection().isProjectionScaled();
				return true;

			case R.id.action_auto_rotate:
				if (mMapView.isAutoRotateEnabled()) {
					mMapView.setAutoRotateEnabled(false, false);

					mMapContainerView.requestLayout();

					mHnadler.removeCallbacks(mTestAutoRotation);
				} else {

					mMapView.setAutoRotateEnabled(true, false);

					mMapView.setRotateAngle(30);
					mHnadler.postDelayed(mTestAutoRotation, AUTO_ROTATE_INTERVAL);

					mMapContainerView.requestLayout();
				}
				return true;
			case R.id.action_navermap:
				mMapView.executeNaverMap();
				return true;

		}
		return false;
	}

	private void invalidateMenu() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			invalidateOptionsMenu();
		}
	}

	private static final long AUTO_ROTATE_INTERVAL = 2000;
	private final Handler mHnadler = new Handler();
	private final Runnable mTestAutoRotation = new Runnable() {
		@Override
		public void run() {
		}
	};

	private class MapContainerView extends ViewGroup {

		public MapContainerView(Context context) {
			super(context);
		}

		@Override
		protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
			final int width = getWidth();
			final int height = getHeight();
			final int count = getChildCount();
			for (int i = 0; i < count; i++) {
				final View view = getChildAt(i);
				final int childWidth = view.getMeasuredWidth();
				final int childHeight = view.getMeasuredHeight();
				final int childLeft = (width - childWidth) / 2;
				final int childTop = (height - childHeight) / 2;
				view.layout(childLeft, childTop, childLeft + childWidth, childTop + childHeight);
			}

			if (changed) {
				mOverlayManager.onSizeChanged(width, height);
			}
		}

		@Override
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
			int w = getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec);
			int h = getDefaultSize(getSuggestedMinimumHeight(), heightMeasureSpec);
			int sizeSpecWidth = widthMeasureSpec;
			int sizeSpecHeight = heightMeasureSpec;

			final int count = getChildCount();
			for (int i = 0; i < count; i++) {
				final View view = getChildAt(i);

				if (view instanceof NMapView) {
					if (mMapView.isAutoRotateEnabled()) {
						int diag = (((int)(Math.sqrt(w * w + h * h)) + 1) / 2 * 2);
						sizeSpecWidth = MeasureSpec.makeMeasureSpec(diag, MeasureSpec.EXACTLY);
						sizeSpecHeight = sizeSpecWidth;
					}
				}

				view.measure(sizeSpecWidth, sizeSpecHeight);
			}
			super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		}
	}
}
