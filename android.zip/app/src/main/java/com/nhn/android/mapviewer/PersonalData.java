package com.nhn.android.mapviewer;

public class PersonalData {
    private String member_name;
    private String member_a;
    private String member_b;
    private String member_c;
    private String member_d;
    private String member_e;
    private String member_f;
    private String member_g;

    public String getMember_name() {
        return member_name;
    }
    public String getMember_a() { return member_a; }
    public String getMember_b() {
        return member_b;
    }
    public String getMember_c() { return member_c; }
    public String getMember_d() { return member_d; }
    public String getMember_e() {
        return member_e;
    }
    public String getMember_f() {
        return member_f;
    }
    public String getMember_g() {
        return member_g;
    }


    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public void setMember_a(String member_a) { this.member_a = member_a; }

    public void setMember_b(String member_b) {
        this.member_b = member_b;
    }

    public void setMember_c(String member_c) {
        this.member_c = member_c;
    }

    public void setMember_d(String member_d) {
        this.member_d = member_d;
    }

    public void setMember_e(String member_e) {
        this.member_e = member_e;
    }

    public void setMember_f(String member_f) {
        this.member_f = member_f;
    }

    public void setMember_g(String member_g) {
        this.member_g = member_g;
    }

}