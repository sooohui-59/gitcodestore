package com.nhn.android.mapviewer;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class ResterRequest extends StringRequest {

    final static private String URL = "http://kyung0945.dothome.co.kr/user.php";
    private Map<String, String> map;

    public ResterRequest(String userName, String userCategory, String userGPS, String userTime, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("userName", userName);
        map.put("userCategory", userCategory);
        map.put("userGPS", userGPS);
        map.put("userTime", userTime);
    }

    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
